﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemTestLast.AppDataFiles
{
    class Admin
    {
        public static bool isAdmin = false;
    }
}
