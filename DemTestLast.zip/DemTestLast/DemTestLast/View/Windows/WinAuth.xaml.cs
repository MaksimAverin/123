﻿using DemTestLast.AppDataFiles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DemTestLast.View.Windows
{
    /// <summary>
    /// Логика взаимодействия для WinAuth.xaml
    /// </summary>
    public partial class WinAuth : Window
    {
        public WinAuth()
        {
            InitializeComponent();
        }

        private void BtAuth_Click(object sender, RoutedEventArgs e)
        {

             WinService winService = new WinService();
             winService.Show();
             this.Close();
           
        }

        private void BtReg_Click(object sender, RoutedEventArgs e)
        {
            WinReg winReg = new WinReg();
            winReg.Show();

            this.Close();
        }
    }
}
